//
//  ATPKit.h
//  ATPKit
//
//  Created by Bill Lv on 2018/8/30.
//  Copyright © 2018 Atlas Protocol. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ATPKit.
FOUNDATION_EXPORT double ATPKitVersionNumber;

//! Project version string for ATPKit.
FOUNDATION_EXPORT const unsigned char ATPKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ATPKit/PublicHeader.h>


